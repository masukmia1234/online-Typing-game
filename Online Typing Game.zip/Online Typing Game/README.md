# WordBeater

> Simple speed typing app built with JavaScript

## Use

Run index.html in a browser

Try it - [WordBeater Game](https://bradtraversy.github.io/wordbeater)

## App Info

### Author

Brad Traversy
[Traversy Media](http://www.traversymedia.com)

### Version

1.0.0

### License

This project is licensed under the MIT License
